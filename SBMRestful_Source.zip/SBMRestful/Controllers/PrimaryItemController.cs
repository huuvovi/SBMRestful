﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using System.Dynamic;
using System.Xml.Linq;
using SBMRestful;
using System.Text;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace SBMRestful.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrimaryItemController : ControllerBase
    {
        private readonly string configFilePath = Path.Combine(Directory.GetCurrentDirectory(), "ConfigFields.xml");
        private readonly string authFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Auth.xml");

        // In-memory storage for PrimaryItem objects
        private static List<PrimaryItem> primaryItems = new List<PrimaryItem>();

        private readonly IHttpClientFactory _httpClientFactory;

        // Inject IHttpClientFactory instead of HttpClient directly
        public PrimaryItemController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        // GET: api/PrimaryItem
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Read the dynamic fields from XML config
                var fields = ReadConfigFields();

                // Return the list of fields (you can expand this logic as per your needs)
                //return Ok(new { fields });
                return Ok(primaryItems);
                
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem
        [HttpPost]
        public IActionResult Post([FromBody] PrimaryItem primaryItem)
        {
            try
            {
                // Validate the input model
                if (primaryItem == null || primaryItem.Fields == null || primaryItem.Fields.Count == 0)
                {
                    return BadRequest("Invalid data.");
                }

                // Read the list of valid field names from the XML file
                var validFields = ReadConfigFields();

                // Validate each field in the POST request
                foreach (var field in primaryItem.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Save the item to the in-memory storage
                primaryItems.Add(primaryItem);

                // Here you can save or process the primaryItem as per your needs
                // For now, we are just returning the received data
                return Ok(new { Message = "PrimaryItem successfully received.", Data = primaryItem });
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/BuildCreatePrimaryItem
        [HttpPost("BuildCreatePrimaryItem")]
        public IActionResult GetBuildCreatePrimaryItem([FromBody] PrimaryItem request)
        {
            try
            {
                // Validate the request
                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest("Invalid data: Fields are required.");
                }

                // Read the list of valid field names from the ConfigFields.xml
                var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                foreach (var field in request.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Build the extended field list XML with the values from the request
                var extendedFieldListXml = BuildCreatePrimaryItem(request.Fields); // BuildExtendedFieldListXml(request.Fields);

                // Return the XML as plain text
                return Content(extendedFieldListXml, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/create
        [HttpPost("create")]
        public async Task<IActionResult> PostCreatePrimaryItem([FromBody] PrimaryItem request)
        {
            try
            {
                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest("Invalid data: Fields are required.");
                }
                // Read the list of valid field names from the ConfigFields.xml
                var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                foreach (var field in request.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                var combinedXml = BuildCreatePrimaryItem(request.Fields);

                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallSoapService(soapUrl, combinedXml);

                // Return the response from the SOAP service
                return Content(soapResponse, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/get
        [HttpPost("get")]
        public async Task<IActionResult> PostGetItem([FromBody] PrimaryItem request)
        {
            try
            {
                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest("Invalid data: Fields are required.");
                }
                // Read the list of valid field names from the ConfigFields.xml
                //var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                //foreach (var field in request.Fields.Keys)
                //{
                //    if (!validFields.Contains(field))
                //    {
                //        return BadRequest($"Invalid field name: {field}");
                //    }
                //}

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                var combinedXml = BuildGetItem(request.Fields);

                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallSoapService(soapUrl, combinedXml);
                //var soapResponse = combinedXml;
                // Return the response from the SOAP service
                return Content(soapResponse, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        private string GetSoapUrlFromAuth()
        {
            if (!System.IO.File.Exists(authFilePath))
                throw new FileNotFoundException("Auth.xml not found.");

            var xmlDoc = XDocument.Load(authFilePath);
            var soapUrl = xmlDoc.Descendants("SoapUrl").FirstOrDefault()?.Value;

            if (soapUrl == null)
            {
                throw new InvalidDataException("SoapUrl not found in Auth.xml.");
            }

            return soapUrl;
        }

        // Helper method to call the SOAP service
        private async Task<string> CallSoapService(string soapUrl, string requestXml)
        {
            // Prepare the SOAP envelope with the request XML
            var soapEnvelope = CreateSoapEnvelope(requestXml);

            // Create the HTTP client using IHttpClientFactory
            var client = _httpClientFactory.CreateClient();

            // Create the HTTP content for the SOAP request
            var content = new StringContent(soapEnvelope, Encoding.UTF8, "text/xml");

            // Set the necessary headers
            content.Headers.Add("SOAPAction", "\"\""); // The SOAPAction header may vary depending on your service.

            // Send the POST request to the SOAP service
            var response = await client.PostAsync(soapUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"SOAP request failed with status code {response.StatusCode}");
            }

            // Read and return the response body
            return await response.Content.ReadAsStringAsync();
        }

        // Helper method to create SOAP envelope
        private string CreateSoapEnvelope(string requestXml)
        {
            // Wrap the requestXml in a SOAP envelope
            var soapEnvelope = new StringBuilder();
            //soapEnvelope.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            soapEnvelope.AppendLine("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:aewebservices71\">");
            soapEnvelope.AppendLine($"  <soapenv:Header/>");
            soapEnvelope.AppendLine($"  <soapenv:Body>");
            
            soapEnvelope.AppendLine(requestXml);

            soapEnvelope.AppendLine($"  </soapenv:Body>");
            soapEnvelope.AppendLine("</soapenv:Envelope>");

            return soapEnvelope.ToString();
        }


        private string BuildCreatePrimaryItem(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();
            
            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //xmlStringBuilder.AppendLine("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:aewebservices71\">");
            //xmlStringBuilder.AppendLine($"  <soapenv:Header/>");
            //xmlStringBuilder.AppendLine($"  <soapenv:Body>");
            xmlStringBuilder.AppendLine($"  <urn:CreatePrimaryItem>");

            var AuthXml = BuildAuth();
            xmlStringBuilder.AppendLine(AuthXml);

            var xmlDoc = XDocument.Load(authFilePath);
            var projectID = xmlDoc.Descendants("projectID").FirstOrDefault()?.Value;

            if (projectID == null)
            {
                throw new InvalidDataException("Missing required projectID in Auth.xml.");
            }

            xmlStringBuilder.AppendLine($"<urn:projectID>{projectID}</urn:projectID>");
            
            xmlStringBuilder.AppendLine($"  <urn:item>");            

            var extendedFieldListXml = BuildExtendedFieldListXml(fields);
            xmlStringBuilder.AppendLine(extendedFieldListXml);

            xmlStringBuilder.AppendLine($"  </urn:item>");

            xmlStringBuilder.AppendLine($"  </urn:CreatePrimaryItem>");
            //xmlStringBuilder.AppendLine($"  </soapenv:Body>");
            //xmlStringBuilder.AppendLine("</soapenv:Envelope>");

            return xmlStringBuilder.ToString();

        }

        private string BuildGetItem(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();
                        
            xmlStringBuilder.AppendLine($"  <urn:GetItem>");

            var AuthXml = BuildAuth();
            xmlStringBuilder.AppendLine(AuthXml);

            var itemID = "";

            foreach (var field in fields)
            { 
                if (field.Key == "itemID") itemID = field.Value;
            }

                if (itemID == null || itemID == "")
            {
                throw new InvalidDataException("Missing required itemID");
            }

            xmlStringBuilder.AppendLine($"<urn:itemID>{itemID}</urn:itemID>");            

            xmlStringBuilder.AppendLine($"  </urn:GetItem>");           

            return xmlStringBuilder.ToString();

        }

        // Helper method to read values from Auth.xml and build the XML structure
        private string BuildAuth()
        {
            if (!System.IO.File.Exists(authFilePath))
                throw new FileNotFoundException("Auth.xml not found.");

            // Load the Auth.xml file
            var xmlDoc = XDocument.Load(authFilePath);

            // Extract the values from the XML file
            var userId = xmlDoc.Descendants("userId").FirstOrDefault()?.Value;
            var password = xmlDoc.Descendants("password").FirstOrDefault()?.Value;
            //var projectID = xmlDoc.Descendants("projectID").FirstOrDefault()?.Value;

            // If any of the values are missing, throw an exception
            if (userId == null || password == null)
            {
                throw new InvalidDataException("Missing required values in Auth.xml.");
            }

            // Build the XML string with the required structure
            var xmlStringBuilder = new StringBuilder();
            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            xmlStringBuilder.AppendLine("<urn:auth>");
            xmlStringBuilder.AppendLine($"  <urn:userId>{userId}</urn:userId>");
            xmlStringBuilder.AppendLine($"  <urn:password>{password}</urn:password>");
            xmlStringBuilder.AppendLine("</urn:auth>");
            //xmlStringBuilder.AppendLine($"<urn:projectID>{projectID}</urn:projectID>");

            return xmlStringBuilder.ToString();
        }

        // Helper method to build the XML structure with the field values
        private string BuildExtendedFieldListXml(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();

            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //xmlStringBuilder.AppendLine("<urn:extendedFieldListList>");

            foreach (var field in fields)
            {
                xmlStringBuilder.AppendLine("<urn:extendedFieldList>");
                xmlStringBuilder.AppendLine($"  <urn:name>{field.Key}</urn:name>");
                xmlStringBuilder.AppendLine("  <urn:value>");
                xmlStringBuilder.AppendLine($"    <urn:displayValue>{field.Value}</urn:displayValue>");
                xmlStringBuilder.AppendLine("  </urn:value>");
                xmlStringBuilder.AppendLine("</urn:extendedFieldList>");
            }

            //xmlStringBuilder.AppendLine("</urn:extendedFieldListList>");
            return xmlStringBuilder.ToString();
        }

        // Helper method to read fields from the ConfigFields.xml file
        private List<string> ReadConfigFields()
        {
            if (!System.IO.File.Exists(configFilePath))
                throw new FileNotFoundException("ConfigFields.xml not found.");

            var xmlDoc = XDocument.Load(configFilePath);
            var fields = xmlDoc.Descendants("Field")
                               .Select(x => x.Attribute("name")?.Value)
                               .Where(name => !string.IsNullOrEmpty(name))
                               .ToList();

            return fields;
        }
    }





public class PrimaryItem
    {
        public Dictionary<string, string> Fields { get; set; } = new Dictionary<string, string>();
    }

}

    


